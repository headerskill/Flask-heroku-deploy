import { Hook } from '@oclif/core';
export declare function checkTos(options: any): void;
declare const hook: Hook.Init;
export default hook;
