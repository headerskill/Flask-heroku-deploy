import { Hook } from '@oclif/core';
declare const doRecache: Hook<'update'>;
export default doRecache;
