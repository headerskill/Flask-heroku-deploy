export declare class Editor {
    edit(input: string, options?: {}): any;
}
