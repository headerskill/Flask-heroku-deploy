export declare function updateCache(cachePath: string, cache: any): Promise<void>;
export declare function fetchCache(cachePath: string, cacheDuration: number, options: any): Promise<Array<string>>;
