export default function getGitHubToken(kolkrabbi: any): any;
